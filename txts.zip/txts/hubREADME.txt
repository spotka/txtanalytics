‘The Apex of Hipster XML GeekDOM’ TEI-encoded Dylan and Understanding the Scope ofan Evolving Community of Practice
 Version 1.0
 Authors: 
 Lynne Siemens, University of Victoria
 Ray Siemens, University of Victoria
 Hefeng (Eddie) Wen, University of Victoria
 Cara Leitch, University of Victoria
 Dot Porter, University of Pennsylvania
 Liam Sherriff, University of Victoria
 Karin Armstrong, University of Victoria
 Melanie Chernyk, University of Victoria
 doi:10.25547/M0QV-N890
 
 
 License: 
 Creative Commons BY-NC-ND 4.0
 
 #####################################
 Included Publication Materials:
 #####################################
 
Primary File(s): 
>>> Siemens-et-al-2011-TEI-encoded-Dylan-and-Understanding-the-Scope-of-an-Evolving-Community-of-Practice-Warning.pdf

Archival Info:
>>> hubREADME.txt

 
 --------------------------------------------
 Archival package produced 2022-06-17 03:10:27