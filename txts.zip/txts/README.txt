Enlisting "Vertues Noble & Excelent": Behavior, Credit, and Knowledge Organization in the Social Edition
 Version 1.0
 Authors: 
 Constance Crompton, U Ottawa
 Ray Siemens, UVic
 Alyssa Arbuckle, UVic
 INKE Research Group, N/A
 
 
 License: 
 Creative Commons BY-ND 4.0
 
 #####################################
 Included Publication Materials:
 #####################################
 
Primary File(s): 
>>> CromptonSiemensArbuckle_EnlistingVertues_DHQ_2015.pdf

Archival Info:
>>> README.txt

 
 --------------------------------------------
 Archival package produced 2021-03-25 16:43:49